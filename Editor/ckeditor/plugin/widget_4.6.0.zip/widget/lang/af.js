/**
 * @license Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang( 'widget', 'af', {
	'move': 'Klik en trek on te beweeg',
	'label': '%1 widget' // MISSING
} );
