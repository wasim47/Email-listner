/**
 * @license Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang( 'widget', 'ru', {
	'move': 'Нажмите и перетащите, чтобы переместить',
	'label': '%1 виджет'
} );
